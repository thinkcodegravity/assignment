package constructor;

public class Products {
 public String name ="IPhone";
 public double price = 300.00; 
 
 public Products(String n) {
	 name = n;
 }
 public Products(String n, double p) {
	 name = n;
	 price = p;
 }
}
