package InheritanceHomework;

public class FiveExamples {
// 1. Children,Parents
// 2. Car,Bus, Vehicle
// 3. Darmatology, Cardiology, doctor
// 4. Computer engineer, electrical engineer, Engineer
// 5. Employees,Company Service, Company
}
