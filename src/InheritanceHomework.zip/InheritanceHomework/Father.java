package InheritanceHomework;

public class Father {
 public void occupation() {
	 System.out.println("Business");
 }
 public void Car() {
	 System.out.println("Father's Car");
 }
}
