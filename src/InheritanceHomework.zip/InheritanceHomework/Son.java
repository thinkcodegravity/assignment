package InheritanceHomework;

public class Son extends Father{
 public void Study() {
	 System.out.println("MBA");
 }
}
